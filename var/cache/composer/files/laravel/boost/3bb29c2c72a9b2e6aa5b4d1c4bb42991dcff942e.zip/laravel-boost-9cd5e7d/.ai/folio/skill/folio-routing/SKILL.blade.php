---
name: folio-routing
description: "Use this skill for Laravel Folio file-based routing tasks: creating pages with `folio:page`, setting up route parameters or model binding in filenames like `[User].blade.php`, defining named routes with `name()`, applying middleware, debugging Folio 404s, or running `folio:list`. Also trigger when a user is choosing between Folio and web.php for a new page, or wants to add a new URL or page in a Folio-enabled project (`resources/views/pages`). Folio automatically maps Blade templates to routes. Do not trigger for Livewire component, Normal Routing, Standard controller routes, or API endpoints"
license: MIT
metadata:
  author: laravel
---
@php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
@endphp
# Folio routing

## Documentation

Use `search-docs` for detailed Folio patterns and documentation.

## Basic usage

Laravel Folio is a file-based router that creates a new route for every Blade file in the configured directory.

Pages are usually in `resources/views/pages/`, and the file structure determines the routes:

- `pages/index.blade.php` → `/`
- `pages/profile/index.blade.php` → `/profile`
- `pages/auth/login.blade.php` → `/auth/login`

### Listing routes

To list the Folio routes, run `{{ $assist->artisanCommand('folio:list') }}`.

### Creating pages

Always create new `folio` pages and routes with `{{ $assist->artisanCommand('folio:page [name]') }}`, and follow the existing naming conventions.

@boostsnippet("Example folio:page Commands for Automatic Routing", "shell")
// Creates: resources/views/pages/products.blade.php → /products
{{ $assist->artisanCommand('folio:page "products"') }}

// Creates: resources/views/pages/products/[id].blade.php → /products/{id}
{{ $assist->artisanCommand('folio:page "products/[id]"') }}

// Creates: resources/views/pages/users/[User].blade.php → /users/{user} (implicit model binding)
{{ $assist->artisanCommand('folio:page "users/[User]"') }}
@endboostsnippet

## Route parameters vs. model binding

Pick the filename token that matches your intent:

- `[id]` (lowercase) captures a plain route parameter string
- `[User]` (capitalized model class) enables implicit Eloquent model binding
- `[Post:slug]` binds by a custom key instead of `id`

Model binding is case-sensitive in the filename. If you expect a `User` model instance, avoid `[user]`.

@boostsnippet("Route Parameter vs Model Binding Example", "blade")
{{-- pages/users/[id].blade.php --}}
<div>User ID: {{ $id }}</div>

{{-- pages/users/[User].blade.php --}}
<div>User ID: {{ $user->id }}</div>
@endboostsnippet

## Named routes

Add a `name` at the top of each new Folio page to create a named route that other parts of the codebase can reference.

@boostsnippet("Named Routes Example", "php")
use function Laravel\Folio\name;

name('products.index');
@endboostsnippet

## Middleware

@boostsnippet("Middleware Example", "php")
use function Laravel\Folio\{name, middleware};

name('admin.products');
middleware(['auth', 'verified']);
@endboostsnippet

## Page content patterns

Folio pages are normal Blade files. When you create or edit a page, include practical data-loading code.

@boostsnippet("Inline Query Example in a Folio Page", "blade")
@php
use App\Models\Post;

$posts = Post::query()
    ->whereNotNull('published_at')
    ->latest('published_at')
    ->get();
@endphp

<ul>
    @foreach ($posts as $post)
        <li>{{ $post->title }}</li>
    @endforeach
</ul>
@endboostsnippet

@boostsnippet("Render Hook Example for View Data", "php")
<?php
use App\Models\Post;
use Illuminate\View\View;
use function Laravel\Folio\render;

render(function (View $view, Post $post) {
    return $view->with('photos', $post->author->photos);
});
?>
@endboostsnippet

## Verification

1. Run `{{ $assist->artisanCommand('folio:list') }}` to verify that the route is registered
2. Check that the page loads at the expected URL

## Common pitfalls

- Forgetting to add named routes to new Folio pages
- Using `[id]` or `[user]` when model binding requires `[User]`
- Not following existing naming conventions when creating pages
- Creating routes manually in `routes/web.php` instead of using Folio's file-based routing

### Folio 404 debug checklist

1. Run `{{ $assist->artisanCommand('folio:list') }}`
2. If routes are missing, confirm that Folio is mounted (`folio:install` plus provider registration, or `Folio::path(...)`) and that the pages are under the mounted path
3. Verify the filename-to-route mapping (`index.blade.php`, nested paths, and `[id]` versus `[Model]`), then rerun `{{ $assist->artisanCommand('folio:list') }}`
