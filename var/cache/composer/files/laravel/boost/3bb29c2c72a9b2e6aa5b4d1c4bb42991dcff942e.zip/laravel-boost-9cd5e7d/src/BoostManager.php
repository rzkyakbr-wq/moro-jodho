<?php

declare(strict_types=1);

namespace Laravel\Boost;

use InvalidArgumentException;
use Laravel\Boost\Install\Agents\Agent;
use Laravel\Boost\Install\Agents\Amp;
use Laravel\Boost\Install\Agents\Antigravity;
use Laravel\Boost\Install\Agents\ClaudeCode;
use Laravel\Boost\Install\Agents\Codex;
use Laravel\Boost\Install\Agents\Copilot;
use Laravel\Boost\Install\Agents\Cursor;
use Laravel\Boost\Install\Agents\Factory;
use Laravel\Boost\Install\Agents\GrokBuild;
use Laravel\Boost\Install\Agents\Junie;
use Laravel\Boost\Install\Agents\Kiro;
use Laravel\Boost\Install\Agents\OpenCode;
use Laravel\Boost\Install\Agents\Pi;
use Laravel\Boost\Install\Agents\Zed;

class BoostManager
{
    /** @var array<string, class-string<Agent>> */
    private array $agents = [
        'amp' => Amp::class,
        'antigravity' => Antigravity::class,
        'claude_code' => ClaudeCode::class,
        'codex' => Codex::class,
        'copilot' => Copilot::class,
        'cursor' => Cursor::class,
        'factory' => Factory::class,
        'grok_build' => GrokBuild::class,
        'junie' => Junie::class,
        'kiro' => Kiro::class,
        'opencode' => OpenCode::class,
        'pi' => Pi::class,
        'zed' => Zed::class,
    ];

    /**
     * @param  class-string<Agent>  $className
     */
    public function registerAgent(string $key, string $className): void
    {
        if (array_key_exists($key, $this->agents)) {
            throw new InvalidArgumentException("Agent '{$key}' is already registered");
        }

        $this->agents[$key] = $className;
    }

    /**
     * @return array<string, class-string<Agent>>
     */
    public function getAgents(): array
    {
        $agents = $this->agents;
        ksort($agents);

        return $agents;
    }
}
